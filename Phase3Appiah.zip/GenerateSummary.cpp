#include "GradeItem.h"

// Function to convert percentage grade to letter grade
string letterGrade(float score) {
    string grade;
    if (score < 0 || score > 100) {
        grade = "Invalid score";
    }
    else if (score >= 90) {
        grade = "A";
    }
    else if (score >= 80) {
        grade = "B";
    }
    else if (score >= 70) {
        grade = "C";
    }
    else if (score >= 60) {
        grade = "D";
    }
    else {
        grade = "F";
    }
    return grade;
}

// Display summary of grades
void generateSummary(const vector<GradeItem> grades) {
    // Check that there are grades to summarize
    if (grades.size() > 0) {
        // Create variables to store the totals
        int totalMaxGradeHW = 0;
        int totalMaxGradeClassWork = 0;
        int totalMaxGradeQuiz = 0;
        int totalMaxGradeExam = 0;

        int totalGradeHW = 0;
        int totalGradeClassWork = 0;
        int totalGradeQuiz = 0;
        int totalGradeExam = 0;


        // Loop through the vector, for each grade, add the maxGrade and grade to the correct grade type totals
        for (GradeItem grade : grades) {
            if (grade.getType() == "HW") {
                totalMaxGradeHW += grade.getMaxGrade();
                totalGradeHW += grade.getGrade();
            }
            else if (grade.getType() == "Quiz") {
                totalMaxGradeQuiz += grade.getMaxGrade();
                totalGradeQuiz += grade.getGrade();
            }
            else if (grade.getType() == "Class Work") {
                totalMaxGradeClassWork += grade.getMaxGrade();
                totalGradeClassWork += grade.getGrade();
            }
            else if (grade.getType() == "Exam") {
                totalMaxGradeExam += grade.getMaxGrade();
                totalGradeExam += grade.getGrade();
            }
        }

        // Calculate grand total max grade
        int grandTotalMaxGrade = totalMaxGradeHW + totalMaxGradeQuiz +
                                 totalMaxGradeClassWork + totalMaxGradeExam;
        // Calculate grand total grade
        int grandTotalGrade = totalGradeHW + totalGradeQuiz +
                              totalGradeClassWork + totalGradeExam;
        // Calculate percentage grade
        float gradePercentage = float(grandTotalGrade) * 100 / float(grandTotalMaxGrade);

        // Call displayGrades() function to display the grades
        displayGrades(grades);
        // Output the summary details obtained from above
        cout << "---------------------------------------------------------" << endl;
        cout << "Summary" << endl;
        printf("%-50s%-10d %-10d\n", "HW", totalMaxGradeHW, totalGradeHW);
        printf("%-50s%-10d %-10d\n", "ClassWork", totalMaxGradeClassWork, totalGradeClassWork);
        printf("%-50s%-10d %-10d\n", "Quiz", totalMaxGradeQuiz, totalGradeQuiz);
        printf("%-50s%-10d %-10d\n", "Exam", totalMaxGradeExam, totalGradeExam);
        cout << "---------------------------------------------------------" << endl;
        printf("%-50s%-10d %-10d\n", "Grand Total", grandTotalMaxGrade, grandTotalGrade);
        printf("%-60s %-20.2f\n", "Grand Percentage", gradePercentage);
        printf("%-60s %-20s\n", "Letter Grade", letterGrade(gradePercentage).c_str());
    }
    else {
        cout << "There are no grades to summarize!" << endl;
    }
}