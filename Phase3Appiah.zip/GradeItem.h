#ifndef GRADEITEM_H
#define GRADEITEM_H
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class GradeItem {
private:
    // Private class data members
    string date;
    string description;
    string type;
    int max_grade;
    int grade;

public:
    // Default constructor
    GradeItem();
    // Constructor with parameters
    GradeItem(string, string, string, int, int);

    // Data Member Setters
    void setDate(string);
    void setDescription(string);
    void setType(string);
    void setMaxGrade(int);
    void setGrade(int);

    // Data Member Getters
    string getDate(void) const;
    string getDescription(void) const;
    string getType(void) const;
    int getMaxGrade(void) const;
    int getGrade(void) const;
};

// Non-class functions to be implemented in their own .cpp files
void readFile(string file, vector<GradeItem>&);
void writeFile(string filename, const vector<GradeItem>);
void displayGrades(const vector<GradeItem>);

// Phase 2: R8: Summary function
void generateSummary(const vector<GradeItem>);

#endif // !GRADEITEM_H
