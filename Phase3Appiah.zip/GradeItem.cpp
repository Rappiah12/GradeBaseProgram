#include "GradeItem.h"

// Default constructor: sets data members to default values awaiting to be set to the actual values
GradeItem::GradeItem() {
    this->setDate("Not set");
    this->setDescription("Not set");
    this->setType("Not set");
    this->setMaxGrade(0);
    this->setGrade(0);
}
// Constructor with parameters that are used to initialize the data members
GradeItem::GradeItem(string date, string description, string type, int max_grade, int grade) {
    this->setDate(date);
    this->setDescription(description);
    this->setType(type);
    this->setMaxGrade(max_grade);
    this->setGrade(grade);
}

// Data Member Setters: take a parameter of the member's type and use it to set the value
void GradeItem::setDate(string date) {
    this->date = date;
}
void GradeItem::setDescription(string description) {
    this->description = description;
}
void GradeItem::setType(string type) {
    this->type = type;
}
void GradeItem::setMaxGrade(int max_grade) {
    this->max_grade = max_grade;
}
void GradeItem::setGrade(int grade) {
    this->grade = grade;
}

// Data Member Getters: take no parameters hence (void) and do not modify data members hence const
// Return data of the type of the data member
string GradeItem::getDate(void) const {
    return this->date;
}
string GradeItem::getDescription(void) const {
    return this->description;
}
string GradeItem::getType(void) const {
    return this->type;
}
int GradeItem::getMaxGrade(void) const {
    return this->max_grade;
}
int GradeItem::getGrade(void) const {
    return this->grade;
}