#include <fstream>
#include <iostream>
#include "GradeItem.h"

// Function to read csv file data and create grade item objects which are then added to the vector passed in by reference from database
void readFile(string filename, vector<GradeItem>& grades) {
    ifstream file;
    // Try .. catch block to handle file not found exception
    try {
        file.open(filename);
        if (file.fail()) {
            throw exception();
        }
        else {
            // Read top line containing column headers first
            string header;
            getline(file, header, '\n');
            // Loop through the rest of the file reading each value up to the comma
            // Then use the values to create a grade item object to add to the vector
            string date, description, type, max_grade, grade;
            while (!file.eof()) {
                getline(file, date, ',');
                getline(file, description, ',');
                getline(file, type, ',');
                getline(file, max_grade, ',');
                getline(file, grade, '\n');
                GradeItem new_grade(date, description, type, stoi(max_grade), stoi(grade));
                grades.push_back(new_grade);
            }
            cout << "Successfully read grades from " << filename << endl;
        }
    }
    catch (exception e) {
        // Display error message if the filename is invalid
        cerr << "File " << filename << " not found! Please enter a valid file name." << endl;
    }

    file.close();
}

