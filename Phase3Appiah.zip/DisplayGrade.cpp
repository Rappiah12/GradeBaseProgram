#include <cstdio>
#include "GradeItem.h"

// Function to display grades stored in a vector using printf
void displayGrades(const vector<GradeItem> grades) {
    if (grades.size() > 0) {
        // Output the column headers
        printf("\n%-10s %-25s %-12s %-10s %-10s\n", "Date", "Description", "Type", "MaxGrade", "Grade");
        // Loop through vector outputting each grade following same formatting as the column headers
        for (int i = 0; i < grades.size(); ++i) {
            printf("%-10s %-25s %-12s %-10d %-10d\n",
                   grades.at(i).getDate().c_str(),
                   grades.at(i).getDescription().c_str(),
                   grades.at(i).getType().c_str(),
                   grades.at(i).getMaxGrade(),
                   grades.at(i).getGrade());
        }
    }
    else {
        cout << "There are no grades to display!" << endl;
    }
}

