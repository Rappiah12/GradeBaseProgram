#include <iostream>
#include "GradeItem.h"

// Function to display a menu given the number of options and a string array containing the labels and corresponding options
string menu(int no_of_options, string options[]) {
    cout << endl << "=========================[ MAIN MENU ]========================" << endl;
    cout << endl << "READ THIS VERY IMPORTANT: DO NOT USE SPACES WHEN TYPING IN SELECTION IT WILL CAUSE ERRORS" << endl;
    // Loop through the menu options displaying each with its corresponding label..
    // The label is at position i and the option is at i + 1
    for (int i = 0; i < no_of_options*2 - 1; i+=2) {
        cout << options[i] << options[i+1] << endl;
    }
    cout << "=========================================================" << endl;
    // Get user input of their menu choice selection
    string choice;
    cout << "Choice : ";
    getline(cin, choice, '\n');
    // Return the selected choice to the main function for processing
    return choice;
}

// Function for requesting for a filename from the user
// It supports the functions to read csv files and writing to a file by getting the filename from the user and passing it to respective function
string getFileName() {
    string filename;
    cout << "\tEnter the name of the file : ";
    getline(cin, filename, '\n');
    return filename;
}

// Function that checks whether a string is only made of numbers
// It helps validate max_grade and grade input from user to ensure grade item object in initialized with correct data types for the grades
bool isValidNumber(string num) {
    bool valid_digit = true;
    for (char c : num) {
        if (isdigit(c) == 0) {
            valid_digit = false;
            break;
        }
    }
    return valid_digit;
}

// Function that allows a user to add a grade to the list of grades in the database
GradeItem addGrade() {
    // Request the user to enter all the grade object data
    string date, description, type, max_grade, grade;
    cout << "\tEnter date : ";
    getline(cin, date, '\n');

    cout << "\tEnter description : ";
    getline(cin, description, '\n');

    cout << "\tEnter type : ";
    getline(cin, type, '\n');

    // For max_grade and grade, use a do .. while loop to ensure the user only enters numbers
    // Use isValidNumber() function from above to check the input string
    do {
        cout << "\tEnter max grade : ";
        getline(cin, max_grade, '\n');
        if (!isValidNumber(max_grade))
            cout << "\tPlease enter numbers only!" << endl;
    } while (!isValidNumber(max_grade));

    do {
        cout << "\tEnter grade : ";
        getline(cin, grade, '\n');
        if (!isValidNumber(grade))
            cout << "\tPlease enter numbers only!" << endl;
    } while (!isValidNumber(grade));

    // Create the grade item object with the provided input, converting the grades to int and return the object to main function
    GradeItem new_grade(date, description, type, stoi(max_grade), stoi(grade));
    cout << "Grade added successfully!" << endl;
    return new_grade;
}

// Function that allows user to search for items within the database either by date or description
void searchForGrade(vector<GradeItem> grades) {
    // Create sub-menu and use the menu function to display it.. indent it to create a distinction from the main menu
    string sub_menu[] = {
            "\tR3.1: ", "Search by date",
            "\tR3.2: ", "Search by description"
    };
    vector<GradeItem> results;
    string selection;
    selection = menu(2, sub_menu);
    // If the user selects to search by date, ask them to enter a date then loop through the grades searching for grades matching given date
    // Add the matches to the results vector
    if (selection == "R3.1" || selection == "r3.1") {
        string date;
        cout << "\tEnter the date to search : ";
        getline(cin, date, '\n');
        for (int i = 0; i < grades.size(); ++i) {
            if (grades.at(i).getDate() == date)
                results.push_back(grades.at(i));
        }
    }
        // If they select description, request for the description to be searched
        // Then search through the grades vector adding any matches to the results vector
    else if (selection == "R3.2" || selection == "r3.2") {
        string description;
        cout << "\tEnter the description to search : ";
        getline(cin, description, '\n');
        for (int i = 0; i < grades.size(); ++i) {
            if (grades.at(i).getDescription() == description)
                results.push_back(grades.at(i));
        }
    }
        // In case of any other input, display message to indicate invalid option
    else {
        cout << "Invalid choice! Please select a valid option." << endl;
    }

    // Check whether there are any grades in results vector at the end
    // If not, there were no matches found
    if (results.size() == 0) {
        cout << "There are no records matching your search!" << endl;
    }
        // Otherwise, display the grades that were found by using the displayGrades() function
    else {
        displayGrades(results);
    }

}

int main() {
    // Vector to hold grades
    vector<GradeItem> grades;
    // Create menu options array to pass to menu() function for displaying and prompting for user choice
    string main_menu[] = {
            "R1 - ", "Read the csv formatted database file.",
            "R2 - ", "Add a new grade item.",
            "R3 - ", "Search for grade items (By date or description).",
            "R6 - ", "Save the grade items into a csv formatted file.",
            "R7 - ", "Display list of grade items on screen.",
            "R8 - ", "Generate summary of grade items.",
            "Exit - ", "End the program."
    };
    string selection;
    // Use a do .. while loop to always display the menu after a selection and processing has been made
    do {
        cout << endl << "---------------------------------------------------------" << endl;
        printf("%-15s%-25s%-15s\n", "", "CSCI 2421 Grade Database (RA)", "");

        // Get the user choice from the menu function
        // Then use if statements to call the respective function to process the menu option
        selection = menu(7, main_menu);

        // Load grades from CSV file if choice is R1.. using readFile function from ReadCsv.cpp
        if (selection == "R1" || selection == "r1") {
            readFile(getFileName(), grades);
        }
            // Add a grade to the vector using the function addGrade described above
        else if (selection == "R2" || selection == "r2") {
            grades.push_back(addGrade());
        }
            // Use function searchForGrade() to search for grades as per the search option that user will select
        else if (selection == "R3" || selection == "r3") {
            searchForGrade(grades);
        }
            // Write the current grades data to a CSV file using writeFile() function from WriteCsv.cpp
        else if (selection == "R6" || selection == "r6")
            writeFile(getFileName(), grades);
            // Display all the current grades using displayGrades() from DisplayGrade.cpp
        else if (selection == "R7" || selection == "r7")
            displayGrades(grades);
            // Display grades summary
        else if (selection == "R8" || selection == "r8")
            generateSummary(grades);
            // Leave the loop and end program
        else if (selection == "Exit" || selection == "exit")
            break;
            // Otherwise, give feedback that choice selected is invalid
        else
            cout << "Invalid choice! Please select a valid option." << endl;

    } while (true); // Allows the loop to run as long as the program has not been closed

    return 0;
}


