/********************************************
 * main.cpp from test file
 *
 * Author: RobertAppiah
 * Version: Phase2
 *********************************************/
#include <iostream>
#include <string>
#include "GradeItem.h"
using namespace std;
/*
 * Main.cpp that was used for testing in phase 1, I redid my project so that it'd work with this main.cpp earlier on
int main() {
    cout << "======================================" << endl;
    cout << "Testing construtor and get functions" << endl;
    cout << "Creating gradeItem" << endl;
    cout << "GradeItem gradeItem (02/22/2022, Homework 1, HW, 100, 85)" << endl;
    GradeItem gradeItem("02/22/2022", "Homework 1", "HW", 100, 85);
    cout << "Using get function to verify data." << endl;
    cout << "Date is: " << gradeItem.getDate() << endl;
    cout << "Description is: " << gradeItem.getDescription() << endl;
    cout << "Type is: " << gradeItem.getType() << endl;
    cout << "Max grade is: " << gradeItem.getMaxGrade() << endl;
    cout << "Grade is: " << gradeItem.getGrade() << endl;
    cout << "======================================" << endl;
    cout << endl;
    cout << "Testing set methods" << endl << endl;
    cout << "Setting date to 05/03/2022" << endl;
    gradeItem.setDate("05/03/2022");
    cout << "Retrieving date" << endl;
    cout << "Date is: " << gradeItem.getDate() << endl;
    cout << endl;
    cout << "Setting description to Midterm Exam" << endl;
    gradeItem.setDescription("Midterm Exam");
    cout << "Retrieving description" << endl;
    cout << "Description is: " << gradeItem.getDescription() << endl;
    cout << endl;
    cout << "Setting type to Exam" << endl;
    gradeItem.setType("Exam");
    cout << "Retrieving type" << endl;
    cout << "Type is: " << gradeItem.getType() << endl;
    cout << endl;
    cout << "Setting Max Score to 500" << endl;
    gradeItem.setMaxGrade(500);
    cout << "Retrieving Max Grade" << endl;
    cout << "Max Grade is: " << gradeItem.getMaxGrade() << endl;
    cout << endl;
    cout << "Setting grade to 400" << endl;
    gradeItem.setGrade(400);
    cout << "Retrieving Grade" << endl;
    cout << "Grade is: " << gradeItem.getGrade() << endl;
    cout << endl;
    return 0;
}
*/