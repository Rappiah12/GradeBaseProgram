#include <fstream>
#include <iostream>
#include "GradeItem.h"

// Function to write grades data into a file
void writeFile(string filename, vector<GradeItem> grades) {
    ofstream outfile;
    outfile.open(filename);
    // Write the column headers
    outfile << "Date,Description,Type,Max Grade,Grade\n";
    // Loop through vector writing each grade info to the file, separated by commas, with an end of line character after each grade
    for (int i = 0; i < grades.size(); ++i) {
        outfile << grades.at(i).getDate() << "," <<
                grades.at(i).getDescription() << "," <<
                grades.at(i).getType() << "," <<
                to_string(grades.at(i).getMaxGrade()) << "," <<
                to_string(grades.at(i).getGrade()) << "\n";
    }
    cout << "Successfully wrote grades to file " << filename << endl;
    outfile.close();
}